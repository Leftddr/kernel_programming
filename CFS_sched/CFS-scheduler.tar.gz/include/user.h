#ifndef	_USER_H
#define	_USER_H

void user_process1(char *array);
void user_process();
extern unsigned long user_begin;
extern unsigned long user_end;

#endif  /*_USER_H */
