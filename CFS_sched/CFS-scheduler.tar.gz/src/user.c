#include "user_sys.h"
#include "user.h"
#include "printf.h"

void loop(char* str)
{
	char buf[2] = {""};
	while (1){
		for (int i = 0; i < 5; i++){
			buf[0] = str[i];
			call_sys_write(buf);
			user_delay(1000000);
		}
	}
}

void loop_n(char* str)
{
	char buf[2] = {""};
	int k = 0;
	while(1) {
		for (int i = 0; i < 5; i++){
			buf[0] = str[i];
			call_sys_write(buf);
			user_delay(1000000);
		}
		k++;
		if(k == 50)
			break;
	}
	call_sys_exit();
}

void user_process() 
{
	call_sys_write("User process\n\r");
	int pid = call_sys_fork();
	
	if (pid < 0) {
		call_sys_write("Error during fork\n\r");
		call_sys_exit();
		return;
	}
	
	if (pid == 0){
		loop("22222");
	} else {
		pid = call_sys_fork();
		if(pid == 0) {
			loop_n("33333");
		} else {
			loop("11111");
		}
	}
}

